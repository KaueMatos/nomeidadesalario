import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Saudação',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _nome = '';
  int _idade = 0;
  double _salario = 0.0;

  TextEditingController _nomeController = TextEditingController();
  TextEditingController _idadeController = TextEditingController();
  TextEditingController _salarioController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Saudação'),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Digite seu nome: ',
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(height: 20.0),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 50.0),
                child: TextField(
                  controller: _nomeController,
                  onChanged: (value) {
                    setState(() {
                      _nome = value;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Digite seu nome: ',
                  ),
                ),
              ),
              SizedBox(height: 20.0),
              Text(
                'Digite sua idade: ',
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(height: 20.0),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 50.0),
                child: TextField(
                  controller: _idadeController,
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      _idade = int.tryParse(value) ?? 0;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Digite sua idade: ',
                  ),
                ),
              ),
              SizedBox(height: 20.0),
              Text(
                'Digite seu salário: ',
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(height: 20.0),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 50.0),
                child: TextField(
                  controller: _salarioController,
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      _salario = double.tryParse(value) ?? 0.0;
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Digite seu salário: ',
                  ),
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      if (_nome.isNotEmpty) {
                        _mostrarMensagem(
                          context,
                          'Olá, $_nome!\nIdade: $_idade\nSalário: R\$ $_salario',
                        );
                      } else {
                        _mostrarMensagem(
                            context, 'Por favor, digite seu nome.');
                      }
                    },
                    child: Text('Mostrar Saudação'),
                  ),
                  SizedBox(width: 10.0),
                  ElevatedButton(
                    onPressed: () {
                      _limparCampos();
                    },
                    child: Text('Limpar'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _mostrarMensagem(BuildContext context, String mensagem) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Mensagem'),
          content: Text(mensagem),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _limparCampos() {
    _nomeController.clear();
    _idadeController.clear();
    _salarioController.clear();
    setState(() {
      _nome = '';
      _idade = 0;
      _salario = 0.0;
    });
  }
}
