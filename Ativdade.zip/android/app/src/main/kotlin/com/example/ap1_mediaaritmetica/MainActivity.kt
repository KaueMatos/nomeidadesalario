package com.example.ap1_mediaaritmetica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
